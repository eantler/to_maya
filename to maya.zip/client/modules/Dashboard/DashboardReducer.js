import { TOGGLE_LOGIN } from './DashboardActions';

// Initial State
const initialState = { data: [] };

const PostReducer = (state = initialState, action) => {
  switch (action.type) {

    default:
      return state;
  }
};

/* Selectors */


// Export Reducer
export default PostReducer;
