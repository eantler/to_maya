

module.exports = {

  GOOGLE_CLIENT_ID: '972925040796-9gpf2eiscp1hfagga7n3dhuk8cf6aa5k.apps.googleusercontent.com',
  GOOGLE_CLIENT_SECRET: '1ww1hMzP_JzOEvrasyWWbrnb',
  callbackURL: 'http://localhost:8000/auth/google/callback'
}
